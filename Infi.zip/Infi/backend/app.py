from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
import sqlite3
import os

app = Flask(__name__)
CORS(app)

# 🔑 Gemini API key
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY") or "YOUR_GEMINI_API_KEY"
genai.configure(api_key=GOOGLE_API_KEY)

model = genai.GenerativeModel("gemini-1.5-flash")

DB_PATH = "machine_data.db"  # change if needed


# -----------------------------
# Home (optional)
# -----------------------------
@app.route("/")
def home():
    return "Backend running 🚀"


# -----------------------------
# Chatbot
# -----------------------------
@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    message = data.get("message", "")

    response = model.generate_content(message)
    return jsonify({"reply": response.text})


# -----------------------------
# Generate SQL from prompt
# -----------------------------
@app.route("/generate-sql", methods=["POST"])
def generate_sql():
    data = request.json
    prompt = data.get("prompt", "")

    response = model.generate_content(prompt)
    sql = response.text.strip()

    return jsonify({"sql": sql})


# -----------------------------
# Run SQL on database
# -----------------------------
@app.route("/run-sql", methods=["POST"])
def run_sql():
    data = request.json
    sql = data.get("sql", "")

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute(sql)
        rows = cursor.fetchall()
        cols = [desc[0] for desc in cursor.description]

        conn.close()

        results = [dict(zip(cols, row)) for row in rows]
        return jsonify(results)

    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(debug=True)
