//json+ gemini
//gemini commented out

import dotenv from "dotenv";
dotenv.config();

import express from "express";

import cors from "cors";
import axios from "axios";

const app = express();

app.use(cors());
app.use(express.json());
/* ---------- JSON ---------- */
import fs from "fs";
import path from "path";

let knowledgeBase = null;   // cache
let knowledgeLoaded = false;


function loadKnowledgeBase() {
  if (!knowledgeLoaded) {
    try {
      console.log("📦 Loading knowledge.json...");
      const filePath = path.resolve("knowledge.json");
      knowledgeBase = JSON.parse(fs.readFileSync(filePath, "utf-8"));
      knowledgeLoaded = true;
    } catch (err) {
      console.error("❌ Failed to load knowledge.json:", err.message);
      knowledgeBase = {};
      knowledgeLoaded = true;
    }
  }
}



function getAnswerFromJSON(question) {
  const q = question.toLowerCase();

  for (const key in knowledgeBase) {
    if (q.includes(key)) {
      return knowledgeBase[key];
    }
  }
  return null;
}

/* ---------- RUN chat ---------- */

app.post("/chat", async (req, res) => {
  try {
    console.log("🟢 /chat called");
    console.log("REQ BODY:", req.body);

    const { prompt } = req.body;

    if (typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({
        error: "prompt must be a non-empty string"
      });
    }
    // ✅ LOAD JSON ON FIRST CALL
    loadKnowledgeBase();

    // ✅ CHECK JSON FIRST
    const localAnswer = getAnswerFromJSON(prompt);

    if (localAnswer) {
      console.log("📦 Answer from JSON");
      return res.json({
        reply: localAnswer,
        source: "json"
      });
    }

    //remove this return for gemini to work
    return res.json({
        reply: "I’m not sure about that yet, but I’m learning!",
        source: "json"
      });

    //gemini

    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        contents: [
          {
            role: "user",
            parts: [{ text: prompt }]
          }
        ]
      }
    );

    const reply =
      response.data?.candidates?.[0]?.content?.parts?.[0]?.text;

    console.log("🤖 Gemini reply:", reply);

    if (!reply) {
      return res.status(500).json({ error: "Empty Gemini response" });
    }

    res.json({ reply: reply.trim() });

  } catch (err) {
    console.error("❌ Gemini chat error:", err.response?.data || err.message);
    res.status(500).json({ error: "Gemini chatbot error" });
  }
});




/* ---------- SERVER ---------- */

app.listen(5000, () => {
  console.log("🚀 Backend running at http://localhost:5000");
});
